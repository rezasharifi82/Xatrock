
package xat.finall;

import java.awt.*;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ResourceBundle;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import javafx.application.Platform;
import javafx.embed.swing.SwingNode;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;


public class WebCamPageController implements Initializable {

    @FXML
    private AnchorPane anchorePane;
    @FXML
    public static String notif=null;
    private SwingNode nodePane;
    private static Webcam webcam = null;
    private static WebcamPanel panel = null;
    private static final long serialVersionUID = 6441489157408381878L;
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       nodePane=new SwingNode();
       create_swing_content(nodePane);
       anchorePane.getChildren().add(nodePane);

    }    

    public static void create_swing_content(final SwingNode swingNode){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                set_those_things();
                swingNode.setContent(panel);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Result result;
                        do {
                            result = null;
                            BufferedImage image = null;

                            if (webcam.isOpen()) {

                                if ((image = webcam.getImage()) == null) {
                                    continue;
                                }

                                LuminanceSource source = new BufferedImageLuminanceSource(image);
                                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                                try {
                                    result = new MultiFormatReader().decode(bitmap);
                                } catch (NotFoundException e) {

                                    // fall thru, it means there is no QR code in image
                                }
                            }

                            if (result != null) {
                                //textarea.setText(result.getText());
                                System.out.println(result);
                                //Platform.exit();
                                notif=result.toString();
                               // System.exit(1);
                                webcam.close();
                                panel=null;
                                JLabel me;
                                me=new JLabel("Now Close This");
                                me.setForeground(Color.red);
                                swingNode.setContent(me);
                                Platform.runLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        new LoginPageController().show_time();

                                    }
                                });
                                //Xatrock.bravox();
                            }

                        } while (result==null);
                    }
                }).start();
            }
        });
    }

    public static void set_those_things(){
        Dimension size = WebcamResolution.QVGA.getSize();
        webcam = Webcam.getWebcams().get(0);
        webcam.setViewSize(size);

        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(false);
    }
}
