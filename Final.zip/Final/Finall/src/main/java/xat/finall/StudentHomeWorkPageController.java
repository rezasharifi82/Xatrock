
package xat.finall;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;


public class StudentHomeWorkPageController implements Initializable {

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
