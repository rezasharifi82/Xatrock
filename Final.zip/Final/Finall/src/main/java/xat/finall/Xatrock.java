
package xat.finall;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import xat.Chat.Client;
import xat.Chat.webcam;

import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;


public class Xatrock extends Application {
    static Object iop;
    static Stage m;
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));

        Scene scene = new Scene(root);
        String cssBg = this.getClass().getResource("background.css").toExternalForm();
        scene.getStylesheets().add(cssBg);
        stage.setScene(scene);
        stage.getIcons().add(new Image(getClass().getResource("logo.png").toExternalForm()));
        stage.setTitle("Xatrock");
        stage.show();
        //------------------------------------------
       iop= this;
        //bravo3(iop);



    }

    
    public static void main(String[] args) {
        launch(args);
        //new webcam();



//        Email.send("salehmhosseini2002@gmail.com" , "test" , "hi");
    
    }

    public static void bravo3(Object ioi){

        Parent foot = null;
        try {
            foot = FXMLLoader.load(ioi.getClass().getResource("WebCamPage.fxml"));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        m=new Stage();
        Scene sene = new Scene(foot);
        m.setScene(sene);
        m.getIcons().add(new Image(ioi.getClass().getResource("logo.png").toExternalForm()));
        m.setTitle("Webcam");

        m.show();
    }
    public static void bravox() {

        m.close();


    }
}
