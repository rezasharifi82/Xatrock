package xat.API;


public class main {
    public static void main(String[] args) {
        int i=0;

        Email.send("sharifi.spam2002@gmail.com","sub4554ject","text");
        System.out.println(1545);
    }
}
