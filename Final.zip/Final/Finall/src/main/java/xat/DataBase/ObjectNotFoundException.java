package xat.DataBase;

public class ObjectNotFoundException extends RuntimeException {
    public ObjectNotFoundException() {
        super("Object Not Found!");
    }

}
