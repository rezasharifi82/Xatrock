module xat.finall {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.logging;
    requires java.sql;
    requires org.hibernate.orm.core;
    requires json.simple;
    requires java.naming;
    requires java.mail;
    requires jakarta.persistence;
    requires mysql.connector.java;
    requires java.desktop;
   // requires poi;
    //requires poi.ooxml;
    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;
    requires itextpdf;
    requires webcam.capture;
    requires core;
    requires com.google.zxing.javase;
    requires javafx.swing;
    //requires org.apache.poi;
    //requires poi;
    //requires poi.ooxml;


    opens xat.finall to javafx.fxml;
    exports xat.finall;
    opens xat.DataBase;

}